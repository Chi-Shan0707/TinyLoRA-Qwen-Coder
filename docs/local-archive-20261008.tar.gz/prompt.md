 你是一名大模型微调专家。 现在我需要你根据TODOLIST.md中的需求（实现新数据库 ，版本号仍为3.2）
  )，你可以通过多种办法进行尝试，并选择最优雅的一种。同时，ckground.md记录了关键信息：比如我的con
    da环境需要conda activate qwenenv,我建议你所有查看版本号的python尝试前，都先conda activate qwenenv