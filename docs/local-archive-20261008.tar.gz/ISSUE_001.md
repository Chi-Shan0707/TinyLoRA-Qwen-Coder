感谢分享！
在使用多GPU训练时，遇到如下报错：

环境：
GPU: 2块A800
CUDA: 12.6
CUDNN: 9.10.2

多卡训练指令：
CUDA_VISIBLE_DEVICES=0,1 torchrun --nproc_per_node=2 train_rl.py 32 32 --do_validate --val_steps 10 --val_samples 10

报错信息：
[rank1]: Traceback (most recent call last):
[rank1]: File "/dfs/data/TinyLoRA-Qwen-Coder/train_rl.py", line 560, in
[rank1]: trainer.train()
[rank1]: ~~~~~~~~~~~~~^^
[rank1]: File "/dfs/data/miniforge3/envs/tinylora_qwen/lib/python3.13/site-packages/transformers/trainer.py", line 1412, in train
[rank1]: return inner_training_loop(
[rank1]: args=args,
[rank1]: ...<2 lines>...
[rank1]: ignore_keys_for_eval=ignore_keys_for_eval,
[rank1]: )
[rank1]: File "/dfs/data/miniforge3/envs/tinylora_qwen/lib/python3.13/site-packages/transformers/trainer.py", line 1742, in _inner_training_loop
[rank1]: tr_loss_step = self.training_step(model, inputs, num_items_in_batch)
[rank1]: File "/dfs/data/miniforge3/envs/tinylora_qwen/lib/python3.13/site-packages/trl/trainer/grpo_trainer.py", line 1094, in training_step
[rank1]: output = super().training_step(model, inputs, num_items_in_batch)
[rank1]: File "/dfs/data/miniforge3/envs/tinylora_qwen/lib/python3.13/site-packages/transformers/trainer.py", line 1945, in training_step
[rank1]: inputs = self._prepare_inputs(inputs)
[rank1]: File "/dfs/data/miniforge3/envs/tinylora_qwen/lib/python3.13/site-packages/trl/extras/profiling.py", line 202, in wrapper
[rank1]: return func(self, *args, **kwargs)
[rank1]: File "/dfs/data/miniforge3/envs/tinylora_qwen/lib/python3.13/site-packages/trl/trainer/grpo_trainer.py", line 1123, in _prepare_inputs
[rank1]: generation_batch = self._generate_and_score_completions(generation_batch)
[rank1]: File "/dfs/data/miniforge3/envs/tinylora_qwen/lib/python3.13/site-packages/trl/trainer/grpo_trainer.py", line 1643, in _generate_and_score_completions
[rank1]: ) = self._generate(prompts)
[rank1]: ~~~~~~~~~~~~~~^^^^^^^^^
[rank1]: File "/dfs/data/miniforge3/envs/tinylora_qwen/lib/python3.13/site-packages/trl/trainer/grpo_trainer.py", line 1509, in _generate
[rank1]: prompt_ids, completion_ids, logprobs, extra_fields = self._generate_single_turn(prompts)
[rank1]: ~~~~~~~~~~~~~~~~~~~~~~~~~~^^^^^^^^^
[rank1]: File "/dfs/data/miniforge3/envs/tinylora_qwen/lib/python3.13/site-packages/trl/trainer/grpo_trainer.py", line 1311, in _generate_single_turn
[rank1]: prompt_completion_ids = unwrapped_model.generate(
[rank1]: **generate_inputs, generation_config=self.generation_config, disable_compile=True
[rank1]: )
[rank1]: File "/dfs/data/miniforge3/envs/tinylora_qwen/lib/python3.13/site-packages/torch/utils/_contextlib.py", line 124, in decorate_context
[rank1]: return func(*args, **kwargs)
[rank1]: File "/dfs/data/miniforge3/envs/tinylora_qwen/lib/python3.13/site-packages/transformers/generation/utils.py", line 2668, in generate
[rank1]: result = decoding_method(
[rank1]: self,
[rank1]: ...<5 lines>...
[rank1]: **model_kwargs,
[rank1]: )
[rank1]: File "/dfs/data/miniforge3/envs/tinylora_qwen/lib/python3.13/site-packages/transformers/generation/utils.py", line 2863, in _sample
[rank1]: outputs = self._prefill(input_ids, generation_config, model_kwargs)
[rank1]: File "/dfs/data/miniforge3/envs/tinylora_qwen/lib/python3.13/site-packages/transformers/generation/utils.py", line 3857, in _prefill
[rank1]: return self(**model_inputs, return_dict=True)
[rank1]: File "/dfs/data/miniforge3/envs/tinylora_qwen/lib/python3.13/site-packages/torch/nn/modules/module.py", line 1776, in _wrapped_call_impl
[rank1]: return self._call_impl(*args, **kwargs)
[rank1]: ~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^
[rank1]: File "/dfs/data/miniforge3/envs/tinylora_qwen/lib/python3.13/site-packages/torch/nn/modules/module.py", line 1787, in _call_impl
[rank1]: return forward_call(*args, **kwargs)
[rank1]: File "/dfs/data/miniforge3/envs/tinylora_qwen/lib/python3.13/site-packages/transformers/utils/generic.py", line 841, in wrapper
[rank1]: output = func(self, *args, **kwargs)
[rank1]: File "/dfs/data/miniforge3/envs/tinylora_qwen/lib/python3.13/site-packages/transformers/models/qwen2/modeling_qwen2.py", line 476, in forward
[rank1]: outputs: BaseModelOutputWithPast = self.model(
[rank1]: ~~~~~~~~~~^
[rank1]: input_ids=input_ids,
[rank1]: ^^^^^^^^^^^^^^^^^^^^
[rank1]: ...<6 lines>...
[rank1]: **kwargs,
[rank1]: ^^^^^^^^^
[rank1]: )
[rank1]: ^
[rank1]: File "/dfs/data/miniforge3/envs/tinylora_qwen/lib/python3.13/site-packages/torch/nn/modules/module.py", line 1776, in _wrapped_call_impl
[rank1]: return self._call_impl(*args, **kwargs)
[rank1]: ~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^
[rank1]: File "/dfs/data/miniforge3/envs/tinylora_qwen/lib/python3.13/site-packages/torch/nn/modules/module.py", line 1787, in _call_impl
[rank1]: return forward_call(*args, **kwargs)
[rank1]: File "/dfs/data/miniforge3/envs/tinylora_qwen/lib/python3.13/site-packages/transformers/utils/generic.py", line 915, in wrapper
[rank1]: output = func(self, *args, **kwargs)
[rank1]: File "/dfs/data/miniforge3/envs/tinylora_qwen/lib/python3.13/site-packages/transformers/utils/output_capturing.py", line 253, in wrapper
[rank1]: outputs = func(self, *args, **kwargs)
[rank1]: File "/dfs/data/miniforge3/envs/tinylora_qwen/lib/python3.13/site-packages/transformers/models/qwen2/modeling_qwen2.py", line 411, in forward
[rank1]: hidden_states = decoder_layer(
[rank1]: hidden_states,
[rank1]: ...<6 lines>...
[rank1]: **kwargs,
[rank1]: )
[rank1]: File "/dfs/data/miniforge3/envs/tinylora_qwen/lib/python3.13/site-packages/transformers/modeling_layers.py", line 93, in call
[rank1]: return super().call(*args, **kwargs)
[rank1]: ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^
[rank1]: File "/dfs/data/miniforge3/envs/tinylora_qwen/lib/python3.13/site-packages/torch/nn/modules/module.py", line 1776, in _wrapped_call_impl
[rank1]: return self._call_impl(*args, **kwargs)
[rank1]: ~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^
[rank1]: File "/dfs/data/miniforge3/envs/tinylora_qwen/lib/python3.13/site-packages/torch/nn/modules/module.py", line 1787, in _call_impl
[rank1]: return forward_call(*args, **kwargs)
[rank1]: File "/dfs/data/miniforge3/envs/tinylora_qwen/lib/python3.13/site-packages/transformers/models/qwen2/modeling_qwen2.py", line 298, in forward
[rank1]: hidden_states, _ = self.self_attn(
[rank1]: ~~~~~~~~~~~~~~^
[rank1]: hidden_states=hidden_states,
[rank1]: ^^^^^^^^^^^^^^^^^^^^^^^^^^^^
[rank1]: ...<6 lines>...
[rank1]: **kwargs,
[rank1]: ^^^^^^^^^
[rank1]: )
[rank1]: ^
[rank1]: File "/dfs/data/miniforge3/envs/tinylora_qwen/lib/python3.13/site-packages/torch/nn/modules/module.py", line 1776, in _wrapped_call_impl
[rank1]: return self._call_impl(*args, **kwargs)
[rank1]: ~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^
[rank1]: File "/dfs/data/miniforge3/envs/tinylora_qwen/lib/python3.13/site-packages/torch/nn/modules/module.py", line 1787, in _call_impl
[rank1]: return forward_call(*args, **kwargs)
[rank1]: File "/dfs/data/miniforge3/envs/tinylora_qwen/lib/python3.13/site-packages/transformers/models/qwen2/modeling_qwen2.py", line 218, in forward
[rank1]: query_states = self.q_proj(hidden_states).view(hidden_shape).transpose(1, 2)
[rank1]: ~~~~~~~~~~~^^^^^^^^^^^^^^^
[rank1]: File "/dfs/data/miniforge3/envs/tinylora_qwen/lib/python3.13/site-packages/torch/nn/modules/module.py", line 1776, in _wrapped_call_impl
[rank1]: return self._call_impl(*args, **kwargs)
[rank1]: ~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^
[rank1]: File "/dfs/data/miniforge3/envs/tinylora_qwen/lib/python3.13/site-packages/torch/nn/modules/module.py", line 1787, in _call_impl
[rank1]: return forward_call(*args, **kwargs)
[rank1]: File "/dfs/data/TinyLoRA-Qwen-Coder/utils.py", line 129, in forward
[rank1]: out = torch.nn.functional.linear(x_cast, W_base, None)
[rank1]: RuntimeError: CUDA error: CUBLAS_STATUS_NOT_SUPPORTED when calling cublasGemmEx( handle, opa, opb, m, n, k, &falpha, a, CUDA_R_16BF, lda, b, CUDA_R_16BF, ldb, &fbeta, c, std::is_same_v<C_Dtype, float> ? CUDA_R_32F : CUDA_R_16BF, ldc, compute_type, CUBLAS_GEMM_DEFAULT_TENSOR_OP)