1. 我是conda环境， conda activate qwenenv将会切到这个项目的环境
2. 我的整体思想可以参见paper-Learning to Reason in 13 Parameters中的论文
3. 采用了deepcoder.md论文的一些思想,所以
    ```python

    beta=0.0,                       # deprecate KL penalty: empower the model to explore more without constraints
    epsilon=0.2,                    # lower bound clipping (1 - epsilon)
    epsilon_high=0.8,               # upper bound clipping (1 + epsilon_high) - Clip High!



    ```