2. Clip Ratio 始终为 0：正常行为，因为 num_iterations=1
这是核心原因链：

你没设 num_iterations，默认值为 1
num_iterations=1 意味着每批生成数据只做一次梯度更新
TRL 的逻辑 (grpo_trainer.py line 1935)：当 gradient_accumulation_steps % generate_every == 0 且不用 vLLM 时，old_per_token_logps = None
在 _compute_loss 中 (line 2281)：old_per_token_logps = per_token_logps.detach()
因此 log_ratio = per_token_logps - per_token_logps.detach() ≡ 0，即 ratio = exp(0) = 1.0
ratio 永远等于 1.0，永远在 [1-0.2, 1+0.8] = [0.8, 1.8] 范围内 → clip 永远不触发
clip_ratio 的判定条件是：

这意味着你的 Clip High 机制 (epsilon_high=0.8) 实际上没有生效。 要让 clipping 真正起作用，你需要设置 num_iterations > 1（例如 DeepCoder 实际训练中可能用的是多次迭代）。

3. 其他指标观察
指标	观察	判断
reward	0.19~0.90，波动大	正常，batch 小 (4 generations) 方差大
frac_reward_zero_std	出现 0.5	说明有些 batch 所有 completion 奖励相同（全通过/全失败），advantage=0，无学习信号
grad_norm	0.05~0.12，很小	只有 32 个可训练参数，梯度本身就小
entropy 趋势	无明显坍塌	符合 DeepCoder 期望（Clip High + No Entropy Loss 应防止 entropy collapse）
建议
如果要让 Clip High 真正发挥作用，在 GRPOConfig 中加：

这样第 2 次迭代时模型已更新，old_per_token_logps ≠ per_token_logps，ratio 会偏离 1，clipping 才会触发。不过，对于只有 32 个参数的 TinyLoRA，每步更新幅度本身极小，即使设置了 num_iterations>1，clip ratio 可能仍然很低。