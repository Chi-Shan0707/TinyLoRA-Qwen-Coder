release: remove test case examples from prompt to prevent OOM

description:
- Stop拼接 input_output/public_tests 到对话模板中：
  * 某些样本的测试用例非常大（200K+ 字符）
  * 拼接后导致 prompt 过长，训练时 OOM
  * 现在 prompt 仅包含问题描述，不含样例

- 训练时限制测试用例数量：
  * code_reward_func 中限制为前 5 个测试用例
  * 避免过多 subprocess fork 导致 OOM killer

- DeepCoder 数据加载时限制：
  * 加载时将 input_output 裁剪为前 5 个测试用例
  * 某些样本携带巨大测试用例导致多 GB 内存膨胀

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
